//
//  AppModel.swift
//  LRF OTA Updater (iOS)
//
//  界面状态与动作 —— 对应安卓 MainActivity 的那一堆字段 + 方法。
//  所有 BLE 回调都在主队列（CBCentralManager(queue: .main)），
//  加上 @MainActor，整个模型只在一个线程上跑。
//

import Foundation
import SwiftUI
import UIKit

@MainActor
final class AppModel: ObservableObject {

    // ① 连接
    @Published var devices: [BleDevice] = []
    @Published var selected: BleDevice?
    @Published var scanning = false
    @Published var btStateText = "Bluetooth is unavailable"

    // ② 固件
    @Published var fwInfo = "No file selected"
    @Published var fwOK = false
    @Published var verifyEach = false

    // 进度
    @Published var progress: Double = 0
    @Published var percentText = "0 %"
    @Published var status = "Not connected"
    @Published var logText = ""
    @Published var busy = false

    // ★ 修复
    @Published var repairText = "Not checked yet"
    @Published var repairedFile: URL?

    let ble: BleCentral
    private let engine: FotaEngine
    private var firmware: Firmware?
    private var task: Task<Void, Never>?

    private let logLimit = 12000

    init() {
        let central = BleCentral()
        ble = central
        engine = FotaEngine(central)

        central.onStateChange = { [weak self] st in
            guard let self = self else { return }
            self.btStateText = self.ble.stateText
            if st != .poweredOn { self.scanning = false }
        }
        central.onDevicesChange = { [weak self] list in
            self?.devices = list
        }

        log("Repair build: the app connects even while the device runs normal firmware, "
            + "and switches it into OTA automatically.")
        log("If it never enters OTA mode, the device carries the old IAP and keeps bouncing back "
            + "to the APP - use [Repair full-chip image] and flash the whole chip once.")
    }

    // MARK: - 日志

    func log(_ s: String) {
        logText += s + "\n"
        if logText.count > logLimit {
            logText = String(logText.dropFirst(4000))
        }
    }

    private func hx(_ v: Int) -> String {
        String(format: "%X", UInt32(truncatingIfNeeded: v))
    }

    // MARK: - 扫描

    func toggleScan() {
        if scanning {
            ble.stopScan()
            scanning = false
            return
        }
        guard ble.isReady else {
            status = ble.stateText
            return
        }
        devices = []
        selected = nil
        scanning = true
        ble.startLiveScan()
    }

    func pick(_ d: BleDevice) {
        selected = d
        ble.stopScan()
        scanning = false
        status = "Selected: \(d.name)   ID \(d.shortId)"
    }

    // MARK: - 固件

    func loadFirmware(url: URL) {
        do {
            let f = try Firmware.load(url: url, log: { [weak self] m in self?.log(m) })
            firmware = f
            fwOK = f.inAppRegion
            var s = "\(f.name)\n\(f.source)   0x\(hx(f.base)) ~ 0x\(hx(f.end))   \(f.size) bytes\n"
            s += String(format: "CRC32=%08X", f.crc32) + "   entry \(f.entry)"
            if !f.inAppRegion {
                s += "\nAddress is outside Image A (0x1000~0x3C000), cannot flash"
            }
            if !f.iapNote.isEmpty { s += "\n" + f.iapNote }
            fwInfo = s
            log("Firmware loaded: \(f.name)  \(f.size) B  "
                + String(format: "CRC32=%08X", f.crc32) + "  entry \(f.entry)")
            if !f.iapNote.isEmpty { log(f.iapNote) }
        } catch {
            firmware = nil
            fwOK = false
            fwInfo = "No file selected"
            status = "Cannot read the file: \(error.localizedDescription)"
            log("!!! Cannot read the file: \(error.localizedDescription)")
        }
    }

    /// 从 App 自己的 Documents 目录读固件。
    ///
    /// 这条路径完全不经过系统文件选择器：Info.plist 里开了 UIFileSharingEnabled，
    /// 所以在「文件」App 里能看到「我的 iPhone > LRF OTA」这个目录，把 .hex
    /// 拷进去（长按 → 拷贝 → 进这个目录 → 粘贴），再点这个按钮就能读。
    /// 没有安全作用域、没有跨 App 提供方，只有 FileManager，最不容易出岔子。
    func loadFromAppFolder() {
        let fm = FileManager.default
        let dir = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let all = (try? fm.contentsOfDirectory(
            at: dir,
            includingPropertiesForKeys: [.contentModificationDateKey],
            options: [.skipsHiddenFiles])) ?? []

        let cands = all.filter {
            let e = $0.pathExtension.lowercased()
            return e == "hex" || e == "bin"
        }.sorted { a, b in
            let da = (try? a.resourceValues(forKeys: [.contentModificationDateKey])
                .contentModificationDate) ?? Date.distantPast
            let db = (try? b.resourceValues(forKeys: [.contentModificationDateKey])
                .contentModificationDate) ?? Date.distantPast
            return da > db
        }

        log("App folder: \(cands.count) firmware file(s) found")
        for f in cands.prefix(6) { log("   \(f.lastPathComponent)") }

        guard let first = cands.first else {
            log("No .hex/.bin here. In Files: copy the file, then open "
                + "On My iPhone > LRF OTA and paste it in, then tap this button again.")
            status = "No .hex/.bin inside the app folder"
            return
        }
        loadFirmware(url: first)
    }

    // MARK: - 升级

    var canStart: Bool { !busy && selected != nil && firmware != nil && fwOK }

    func start() {
        guard let d = selected else { status = "Select a device first"; return }
        guard let fw = firmware else { status = "Select a firmware file first"; return }
        guard task == nil else { return }
        guard let per = ble.peripheral(for: d.id) else {
            status = "This device is no longer known - scan again"
            return
        }

        ble.stopScan()
        scanning = false
        logText = ""
        progress = 0
        percentText = "0 %"
        busy = true
        status = "Starting..."
        UIApplication.shared.isIdleTimerDisabled = true     // 升级中别锁屏

        let verify = verifyEach
        let sink = FotaEngine.Sink(
            stage: { [weak self] t in self?.status = t },
            log: { [weak self] t in self?.log(t) },
            progress: { [weak self] p, t in
                self?.progress = Double(p) / 100.0
                self?.percentText = "\(p) %   \(t)"
            })

        task = Task { [weak self] in
            guard let self = self else { return }
            do {
                try await self.engine.upgrade(peripheral: per, firmware: fw,
                                              verify: verify, sink: sink)
                self.status = "Upgrade complete: the device powered off by itself; "
                    + "press the key to start the new version"
            } catch {
                self.log("!!! \(error.localizedDescription)")
                self.status = "Failed: \(error.localizedDescription)"
            }
            self.busy = false
            self.task = nil
            UIApplication.shared.isIdleTimerDisabled = false
        }
    }

    // MARK: - 整片镜像修复

    func inspectAndRepair(url: URL) {
        repairText = "Checking..."
        repairedFile = nil
        Task { [weak self] in
            guard let self = self else { return }
            do {
                let bytes = try IapRepair.read(url: url)
                let info = IapRepair.inspect(bytes)
                var fixed: [UInt8]?
                if info.fullChip { fixed = try IapRepair.repair(bytes) }

                var text = (info.fullChip ? "Full-chip image" : "APP-only image (no IAP)") + "\n"
                text += "IAP: \(info.iapState)\n"
                text += "IAP entry: \(info.entry)\n"
                text += String(format: "APP region: %d B  CRC32=%08X", info.appBytes, info.appCrc)

                if let f = fixed {
                    let base = String(url.deletingPathExtension().lastPathComponent.prefix(40))
                    let u = try IapRepair.export(f, name: base + "_newIAP.bin")
                    self.repairedFile = u
                    text += "\n\nRepaired image created:\n\(u.lastPathComponent)"
                    text += "\nSaved in Files > On My iPhone > LRF OTA"
                    text += "\nFlash the whole chip over USB once; OTA works again afterwards."
                    self.log("Repaired image exported: \(u.path)")
                } else {
                    text += "\n\nAn APP-only file needs no IAP swap and can be used for OTA directly."
                }

                self.repairText = text
                self.log("IAP check: \(info.iapState); entry \(info.entry)")
                if info.oldIap {
                    self.log("WARNING: old 2024 IAP detected - this is why OTA fails; "
                        + "a repaired image has been generated.")
                }
            } catch {
                self.repairText = "Check failed: \(error.localizedDescription)"
                self.log("!!! Repair failed: \(error.localizedDescription)")
            }
        }
    }
}

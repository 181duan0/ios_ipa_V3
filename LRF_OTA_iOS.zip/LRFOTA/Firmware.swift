//
//  Firmware.swift
//  LRF OTA Updater (iOS)
//
//  固件镜像解析 —— 与安卓 Firmware.kt 逐条对应。
//
//  把 Intel HEX 和原始 BIN 统一解析成一段连续内存 [base, base+bytes.count)，
//  中间的空洞用 0xFF 填满（Flash 擦除后的值，写进去等于没写）。
//
//  ★ BIN 有两种，必须分清（分不清就是"OTA 完开机还是旧程序"的根因）：
//    1. 纯 APP 镜像：第一字节就是 APP 入口（j handle_reset，0x6F 1x ..），
//       应按 0x1000 起始写入；
//    2. WCH_AssemblingFileTool 合出来的整片镜像：0x0 放 JumpIAP
//       （6F C0 03 00）或 0x00 填充，0x1000 才是 APP，后面还跟着 IAP。
//       这种必须先截取 [0x1000, 0x3C000) 再写。
//

import Foundation

struct Firmware {

    static let appStart = 0x1000          // Image A 起点（APP 链接地址）
    static let appLimit = 0x3C000         // Image A 上限（IAP 的擦除检查只允许到 0x3C000）

    /// WCH_AssemblingFileTool 整片镜像的标志：0x0 处的 `jal 0x3C000`
    private static let jumpIap: [UInt8] = [0x6F, 0xC0, 0x03, 0x00]

    let name: String
    let base: Int
    let bytes: [UInt8]
    let source: String        // "HEX" / "HEX (APP region only)" / "BIN" / "BIN (full-chip -> APP region)"
    let iapNote: String       // 整片镜像里 IAP 区的体检结论

    var end: Int { base + bytes.count }
    var size: Int { bytes.count }

    /// 镜像 CRC32 —— 升级前打在日志里，两次一对比就知道发的到底是不是新文件
    var crc32: UInt32 { CRC32.checksum(bytes) }

    /// APP 入口 4 字节（0x1000 处的 j handle_reset）
    var entry: String {
        guard bytes.count >= 4 else { return "--" }
        return String(format: "%02X %02X %02X %02X", bytes[0], bytes[1], bytes[2], bytes[3])
    }

    /// 镜像里 0x1004 的 Image_Flag（手机端判文件有效性用的字段）
    var imageFlag: UInt32 {
        guard bytes.count >= 8 else { return 0 }
        return bytes.le32(4)
    }

    /// 是否落在可写区间
    var inAppRegion: Bool { base >= Firmware.appStart && end <= Firmware.appLimit }

    // MARK: - 载入

    static func load(url: URL, log: (String) -> Void = { _ in }) throws -> Firmware {
        let raw = try readBytes(url: url, log: log)
        guard !raw.isEmpty else { throw OtaError("File is empty") }
        let fname = url.lastPathComponent
        return looksLikeHex(raw) ? try parseHex(raw, fname, log: log) : try fromBin(raw, fname, log: log)
    }

    /// 读取文件。iOS 的 fileImporter 给的是安全作用域 URL，必须成对
    /// start/stop，否则 iCloud 或其它 App 目录里的文件读不出来。
    private static func readBytes(url: URL, log: (String) -> Void) throws -> [UInt8] {
        // 选择器放开了所有类型，用户可能点到文件夹上
        var isDir: ObjCBool = false
        if FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue {
            throw OtaError("That is a folder - please pick the .hex or .bin file itself")
        }

        let scoped = url.startAccessingSecurityScopedResource()
        log("Read \(url.lastPathComponent): security scope "
            + (scoped ? "granted" : "not granted"))
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }

        var data: Data?
        var firstError: String?
        do {
            data = try Data(contentsOf: url)
        } catch {
            firstError = error.localizedDescription
        }

        if data == nil {
            /* 跨 App 提供的文件（「我的 iPhone」里别的 App 的目录、iCloud、
               微信目录）直接读经常失败，换 NSFileCoordinator 再读一次 ——
               这是系统推荐的跨 App 读文件方式，能绕开不少提供方的怪癖。 */
            log("  direct read failed (\(firstError ?? "-")), trying NSFileCoordinator")
            var coordErr: NSError?
            var out: Data?
            NSFileCoordinator().coordinate(readingItemAt: url, options: [], error: &coordErr) { u in
                out = try? Data(contentsOf: u)
            }
            if let o = out {
                data = o
            } else if let ce = coordErr {
                throw OtaError("Cannot read this file (\(ce.localizedDescription))")
            }
        }

        guard let d = data else {
            throw OtaError("Cannot read this file (\(firstError ?? "unknown reason")). "
                + "If it lives in iCloud or a chat app, open it once first so it is downloaded.")
        }
        guard !d.isEmpty else { throw OtaError("File is empty") }
        log("  read \(d.count) bytes")
        return [UInt8](d)
    }

    private static func looksLikeHex(_ b: [UInt8]) -> Bool {
        var i = 0
        // 跳过 UTF-8 BOM 与空白
        if b.count >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF { i = 3 }
        while i < b.count && (b[i] == 0x20 || b[i] == 0x0D || b[i] == 0x0A || b[i] == 0x09) { i += 1 }
        return i < b.count && b[i] == UInt8(ascii: ":")
    }

    /// 整片镜像的判别：要么带 JumpIAP 特征，要么头 4 KB 是填充且 0x1000 有内容
    private static func isFullChipImage(_ raw: [UInt8]) -> Bool {
        if raw.count >= 4 && Array(raw[0 ..< 4]) == jumpIap { return true }
        if raw.count < appStart + 4 { return false }
        for i in 0 ..< appStart {
            let v = raw[i]
            if v != 0x00 && v != 0xFF { return false }   // 头 4 KB 有真代码 → 不是整片
        }
        // 头 4 KB 全是填充：看 0x1000 处像不像 APP 入口（j / jal 的操作码段）
        let e = raw[appStart]
        return e == 0x6F || e == 0x2F || e == 0xEF
    }

    /// 去掉结尾的 0xFF（擦除态，写不写都一样），少擦少写少传
    private static func trimTailFF(_ b: [UInt8]) -> [UInt8] {
        var n = b.count
        while n > 1 && b[n - 1] == 0xFF { n -= 1 }
        return Array(b[0 ..< n])
    }

    /// 整片镜像里 0x3C000 处的 IAP 入口体检
    private static func iapCheck(_ raw: [UInt8]) -> String {
        if raw.count < appLimit + 4 { return "Image has no IAP region (short full-chip)" }
        let e = Array(raw[appLimit ..< appLimit + 4])
        let s = String(format: "%02X %02X %02X %02X", e[0], e[1], e[2], e[3])
        if e == [0x6F, 0x00, 0x40, 0x7B] {
            return "Full-chip image carries the new IAP (\(s), matching)"
        }
        if e == [0x6F, 0x00, 0xC0, 0x76] {
            return "WARNING: full-chip image carries the old 2024 IAP (\(s)) - OTA never writes this region, "
                + "but flashing it over USB puts the device back into the 'cannot enter OTA' state; "
                + "repair it with the repair build first"
        }
        return "Full-chip image IAP entry \(s) (unknown version)"
    }

    private static func fromBin(_ raw: [UInt8], _ name: String,
                                log: (String) -> Void) throws -> Firmware {
        let full = isFullChipImage(raw)
        log("  BIN: \(raw.count) bytes, " + (full ? "full-chip image" : "APP-only image"))
        guard full else {
            // 纯 APP 镜像：默认按 APP 起始地址 0x1000 放
            let img = trimTailFF(raw)
            log("  BIN map 0x\(String(format: "%X", appStart))~0x"
                + "\(String(format: "%X", appStart + img.count)) (\(img.count) B)")
            return Firmware(name: name, base: appStart, bytes: img, source: "BIN", iapNote: "")
        }
        // 整片镜像：只取 APP 区，IAP / 0x40000 库区绝对不能动
        let end = min(raw.count, appLimit)
        if end <= appStart { throw OtaError("This full-chip bin has no APP region") }
        let img = trimTailFF(Array(raw[appStart ..< end]))
        if img.isEmpty { throw OtaError("APP region is empty") }
        log("  BIN APP slice 0x1000~0x\(String(format: "%X", appStart + img.count)) (\(img.count) B)")
        return Firmware(name: name, base: appStart, bytes: img,
                        source: "BIN (full-chip -> APP region)", iapNote: iapCheck(raw))
    }

    /// 一行 HEX 记录的解析结果
    private enum HexLineResult {
        case record      // 有效数据记录
        case skip        // 非数据行（地址记录 / 空行 / 非 hex 内容）
        case eof         // 遇到 01 结束记录
    }

    /// Intel HEX 解析。
    ///
    /// ★ 改成**纯字节**解析（真机上是这里出的问题）。
    ///   旧实现走 String / Character：split + trimmingCharacters +
    ///   Character.hexDigitValue。在 645 KB 的 hex 上一条有效记录都没解析出来，
    ///   报 "No valid address record"，让人误以为是"文件没读进来"——
    ///   实际日志里 read 645509 bytes 是成功的，坏在解析。
    ///   字节级解析不依赖任何字符语义，也不会先把 14 万字符拆成 Character，
    ///   顺带比旧实现快一个量级。
    ///
    ///   格式与安卓 Firmware.kt 完全一致：
    ///     :LLAAAATT[DD..]CC    LL=字节数  AAAA=地址  TT=类型
    ///     00 数据 / 01 结束 / 02 扩展段地址(<<4) / 04 扩展线性地址(<<16) / 03,05 忽略
    ///   空洞填 0xFF，末尾 0xFF 去掉，超出 APP 区(0x1000~0x3C000)自动截取。
    private static func parseHex(_ raw: [UInt8], _ name: String,
                                 log: (String) -> Void) throws -> Firmware {
        var base = 0
        var minA = Int.max
        var maxA = 0
        var pieces: [(Int, [UInt8])] = []

        var lineCount = 0
        var records = 0
        var skipped = 0

        var line: [UInt8] = []
        line.reserveCapacity(80)

        var i = 0
        while i <= raw.count {
            let c: UInt8 = (i == raw.count) ? 0x0A : raw[i]
            if c == 0x0A || c == 0x0D {
                if !line.isEmpty {
                    lineCount += 1
                    switch parseHexLine(line, &base, &pieces, &minA, &maxA) {
                    case .record:
                        records += 1
                    case .skip:
                        skipped += 1
                    case .eof:
                        i = raw.count
                    }
                    line.removeAll(keepingCapacity: true)
                }
            } else {
                line.append(c)
            }
            i += 1
        }

        log("  HEX: \(lineCount) lines, \(records) data records, \(skipped) other"
            + (lineCount <= 1 ? " (no line breaks found?)" : ""))

        guard !pieces.isEmpty, minA != Int.max, maxA > minA else {
            throw OtaError("No valid address record in this HEX file "
                + "(\(lineCount) lines, \(records) usable). "
                + "Check that it is a real Intel HEX, not a renamed .bin.")
        }

        var img = [UInt8](repeating: 0xFF, count: maxA - minA)
        for (a, d) in pieces {
            let off = a - minA
            if off >= 0 && off + d.count <= img.count {
                img.replaceSubrange(off ..< (off + d.count), with: d)
            }
        }

        /* MRS 有时会把 0x40000 的 BLE 库区一起打进 hex；机器上本来就有，
           IAP 也只允许写 0x1000~0x3C000 —— 自动截取 APP 区。 */
        var lo = minA
        var hi = maxA
        var note = "HEX"
        if lo < appStart || hi > appLimit {
            if lo < appStart { lo = appStart }
            if hi > appLimit { hi = appLimit }
            if hi <= lo {
                throw OtaError(String(format: "HEX 0x%X~0x%X has no data inside the APP region (0x%X~0x%X)",
                                      UInt32(truncatingIfNeeded: minA),
                                      UInt32(truncatingIfNeeded: maxA),
                                      UInt32(truncatingIfNeeded: appStart),
                                      UInt32(truncatingIfNeeded: appLimit)))
            }
            note = "HEX (APP region only)"
        }
        let slice = trimTailFF(Array(img[(lo - minA) ..< (hi - minA)]))
        if slice.isEmpty { throw OtaError("APP region is empty after slicing") }

        log(String(format: "  HEX map 0x%X~0x%X, APP slice 0x%X~0x%X (%d B)",
                   UInt32(truncatingIfNeeded: minA), UInt32(truncatingIfNeeded: maxA),
                   UInt32(truncatingIfNeeded: lo), UInt32(truncatingIfNeeded: hi), slice.count))
        return Firmware(name: name, base: lo, bytes: slice, source: note, iapNote: "")
    }

    /// 解析一行。line 不含换行符。
    private static func parseHexLine(_ line: [UInt8],
                                     _ base: inout Int,
                                     _ pieces: inout [(Int, [UInt8])],
                                     _ minA: inout Int,
                                     _ maxA: inout Int) -> HexLineResult {
        // 允许行首有空白 / BOM，往后找 ':' 为止
        var s = 0
        while s < line.count {
            let c = line[s]
            if c == 0x3A { break }                        // ':'
            if c == 0x20 || c == 0x09 || c == 0xEF || c == 0xBB || c == 0xBF {
                s += 1
                continue
            }
            return .skip                                   // 前面有别的字符，不是 hex 行
        }
        if s >= line.count { return .skip }

        // 冒号之后每两个字符一个字节；遇到非 hex 字符整行作废
        var rec: [UInt8] = []
        rec.reserveCapacity(24)
        var k = s + 1
        while k + 1 < line.count {
            guard let hi = hexVal(line[k]), let lo = hexVal(line[k + 1]) else { return .skip }
            rec.append((hi << 4) | lo)
            k += 2
        }
        if rec.count < 5 { return .skip }

        let len = Int(rec[0])
        let addr = (Int(rec[1]) << 8) | Int(rec[2])
        let type = Int(rec[3])

        if type == 0x01 { return .eof }                   // EOF
        if type == 0x02 {                                 // 扩展段地址
            if rec.count >= 6 { base = ((Int(rec[4]) << 8) | Int(rec[5])) << 4 }
            return .skip
        }
        if type == 0x04 {                                 // 扩展线性地址
            if rec.count >= 6 { base = ((Int(rec[4]) << 8) | Int(rec[5])) << 16 }
            return .skip
        }
        if type != 0x00 { return .skip }                  // 03 / 05 起始地址，忽略
        if len == 0 || 4 + len > rec.count { return .skip }

        let abs = base + addr
        pieces.append((abs, Array(rec[4 ..< (4 + len)])))
        if abs < minA { minA = abs }
        if abs + len > maxA { maxA = abs + len }
        return .record
    }

    /// 单字节十六进制值（不依赖 Character 语义）
    private static func hexVal(_ c: UInt8) -> UInt8? {
        switch c {
        case 0x30 ... 0x39: return c - 0x30               // 0-9
        case 0x41 ... 0x46: return c - 0x41 + 10          // A-F
        case 0x61 ... 0x66: return c - 0x61 + 10          // a-f
        default: return nil
        }
    }
}

//
//  DocumentPicker.swift
//  LRF OTA Updater (iOS)
//
//  手动呈现的系统文件选择器。
//
//  为什么不用 SwiftUI 的 .fileImporter：
//    1) 原来在同一个视图上挂了两个 .fileImporter（选固件 / 选整片镜像），
//       SwiftUI 会各自建一套 presentation，实际表现就是"点了文件没反应"、
//       "界面回到原样还是让你选"——这是它的已知坑，不是配置问题。
//    2) .fileImporter 只给安全作用域 URL，某些文件提供方（我的 iPhone 里
//       由别的 App 写入的目录、微信目录、未下载的 iCloud 文件）
//       startAccessingSecurityScopedResource() 会失败，读取异常又常被吞掉，
//       界面看起来就是"选了但没选中"。
//
//  这里直接 present UIDocumentPickerViewController，并且：
//    · 只用一个实例，绝不会有第二个 presentation 抢；
//    · 读取失败会走 NSFileCoordinator 再试一次（跨 App 文件的标准读法）；
//    · 每一步都通过 onLog 打出来，出问题能一眼看到断在哪。
//

import SwiftUI
import UIKit
import UniformTypeIdentifiers

final class DocumentPicker: NSObject, UIDocumentPickerDelegate {

    static let shared = DocumentPicker()

    private var onPick: ((URL) -> Void)?
    private var onCancel: (() -> Void)?
    private var onLog: ((String) -> Void)?
    /// 保留引用：ARC 提前释放 delegate 会让选择器回调永远不来
    private weak var presented: UIDocumentPickerViewController?

    func present(log: @escaping (String) -> Void,
                 onPick: @escaping (URL) -> Void,
                 onCancel: @escaping () -> Void) {
        self.onLog = log
        self.onPick = onPick
        self.onCancel = onCancel

        guard let root = DocumentPicker.topViewController() else {
            log("Picker: no window to present from")
            return
        }
        if root is UIDocumentPickerViewController {
            log("Picker: one is already open, ignoring")
            return
        }

        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: false)
        picker.delegate = self
        picker.allowsMultipleSelection = false
        picker.shouldShowFileExtensions = true
        presented = picker

        log("Picker: presenting (all file types)")
        root.present(picker, animated: true)
    }

    // MARK: UIDocumentPickerDelegate

    func documentPicker(_ controller: UIDocumentPickerViewController,
                        didPickDocumentsAt urls: [URL]) {
        guard let u = urls.first else {
            onLog?("Picker: returned no URL")
            finish()
            return
        }
        onLog?("Picker: chose \(u.lastPathComponent)")
        let cb = onPick
        finish()
        cb?(u)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        onLog?("Picker: cancelled")
        let cb = onCancel
        finish()
        cb?()
    }

    private func finish() {
        onPick = nil
        onCancel = nil
        onLog = nil
        presented = nil
    }

    // MARK: 找最顶层的 view controller

    private static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first
        var vc = scene?.windows.first(where: { $0.isKeyWindow })?.rootViewController
            ?? scene?.windows.first?.rootViewController
        while let p = vc?.presentedViewController {
            // 忽略正在消失的那些，避免叠在已经 dismiss 的控制器上
            if p.isBeingDismissed { break }
            vc = p
        }
        return vc
    }
}

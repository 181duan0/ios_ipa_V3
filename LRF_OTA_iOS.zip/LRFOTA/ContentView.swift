//
//  ContentView.swift
//  LRF OTA Updater (iOS)
//
//  界面按安卓 activity_main.xml 的五块卡片排：连接 / 选固件 / 修复 / 进度 / 日志。
//

import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct ContentView: View {

    @EnvironmentObject private var m: AppModel

    @State private var showShare = false

    var body: some View {
        VStack(spacing: 0) {
            header
            ScrollView {
                VStack(spacing: 10) {
                    connectCard
                    firmwareCard
                    repairCard
                    progressCard
                    logCard
                }
                .padding(12)
            }
        }
        .background(Color(UIColor.systemGroupedBackground).ignoresSafeArea())
        .sheet(isPresented: $showShare) {
            if let u = m.repairedFile {
                ShareSheet(items: [u])
            }
        }
        // 备用入口：在「文件」App 里长按 hex → 共享 → LRF OTA，
        // 或从微信/QQ 里「用其他应用打开」→ LRF OTA。
        .onOpenURL { url in
            m.log("Opened from another app: \(url.lastPathComponent)")
            m.loadFirmware(url: url)
        }
    }

    // MARK: - 外壳

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 1) {
                Text("Ballistic Computer OTA Update")
                    .font(.system(size: 16, weight: .semibold))
                Text("iOS 1.8.2 b14")
                    .font(.system(size: 11))
                    .opacity(0.85)
            }
            .foregroundColor(.white)
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity)
        .background(Color.accentColor.ignoresSafeArea(edges: .top))
    }

    private func cardBox<C: View>(@ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 8, content: content)
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(UIColor.secondarySystemGroupedBackground))
            )
    }

    private func cardTitle(_ s: String, color: Color = .primary) -> some View {
        Text(s)
            .font(.system(size: 14, weight: .bold))
            .foregroundColor(color)
    }

    // MARK: - ① 连接

    private var connectCard: some View {
        cardBox {
            cardTitle("① Connect device")
            Text(m.status)
                .font(.system(size: 13))
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            Button(action: { m.toggleScan() }) {
                Text(m.scanning ? "Stop scan" : "Scan for devices")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(m.busy || !m.ble.isReady)

            if !m.devices.isEmpty {
                ScrollView {
                    VStack(spacing: 6) {
                        ForEach(m.devices) { d in
                            deviceRow(d)
                        }
                    }
                }
                .frame(height: listHeight)
            }

            Text(deviceHint)
                .font(.system(size: 11))
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var listHeight: CGFloat {
        if m.devices.isEmpty { return 0 }
        let rowH: CGFloat = 60
        return min(CGFloat(m.devices.count) * rowH, rowH * 4.5)
    }

    private var deviceHint: String {
        if m.devices.isEmpty {
            if m.scanning { return "Scanning..." }
            return m.ble.isReady ? "No devices found" : m.btStateText
        }
        let n = m.devices.count
        var s = "\(n) device\(n == 1 ? "" : "s") found (sorted by signal strength)"
        if m.scanning { s += " - scanning..." }
        return s
    }

    private func deviceRow(_ d: BleDevice) -> some View {
        let sel = (m.selected?.id == d.id)
        return Button {
            m.pick(d)
        } label: {
            HStack(spacing: 8) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(d.name)
                        .font(.system(size: 14, weight: .medium))
                        .lineLimit(1)
                        .foregroundColor(.primary)
                    Text("ID \(d.shortId)   \(d.rssi) dBm")
                        .font(.system(size: 11))
                        .foregroundColor(.secondary)
                }
                Spacer(minLength: 4)
                if sel {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.accentColor)
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(sel ? Color.accentColor.opacity(0.14)
                              : Color(UIColor.tertiarySystemGroupedBackground))
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: - ② 固件

    private var firmwareCard: some View {
        cardBox {
            cardTitle("② Select firmware")

            Button(action: pickFirmware) {
                Text("Choose file (.hex / .bin)").frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .disabled(m.busy)

            Button(action: { m.loadFromAppFolder() }) {
                Text("Or read from the app folder (Files > On My iPhone > LRF OTA)")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .disabled(m.busy)

            Text("Every step of the pick is written to the Log below (opening, the chosen "
                + "file, security scope, bytes read). If nothing happens, send me those lines. "
                + "If the .hex lives in iCloud, open it once in Files so it is downloaded first.")
                .font(.system(size: 11))
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            Text(m.fwInfo)
                .font(.system(size: 12))
                .foregroundColor(m.fwOK ? .primary : .secondary)
                .fixedSize(horizontal: false, vertical: true)
                .textSelection(.enabled)

            Toggle(isOn: $m.verifyEach) {
                Text("Verify every packet (more robust but ~10x slower; by default it bursts "
                    + "write-without-response and verifies every 32 packets)")
                    .font(.system(size: 12))
            }
            .disabled(m.busy)
        }
    }

    // MARK: - ★ 修复整片镜像

    private var repairCard: some View {
        cardBox {
            cardTitle("★ Repair build: fix a device that cannot enter OTA",
                      color: Color(red: 0.70, green: 0.42, blue: 0.0))

            Text("If the unit runs a new APP together with the old 2024 IAP, an upgrade request "
                + "bounces straight back to the APP and the phone never sees the OTA name. "
                + "This deadlock can only be fixed by flashing the whole chip once: pick that "
                + "full-chip .bin, let the app swap in the matching new IAP and export it, "
                + "then flash the whole chip over USB.")
                .font(.system(size: 12))
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            Button(action: pickRepairImage) {
                Text("① Choose a full-chip .bin, detect / repair").frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .disabled(m.busy)

            Button(action: { showShare = true }) {
                Text("② Share / export the repaired image").frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .disabled(m.repairedFile == nil)

            Text(m.repairText)
                .font(.system(size: 12))
                .fixedSize(horizontal: false, vertical: true)
                .textSelection(.enabled)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.orange.opacity(0.55), lineWidth: 1)
        )
    }

    // MARK: - ③ 进度

    private var progressCard: some View {
        cardBox {
            Button(action: { m.start() }) {
                Text(m.busy ? "Upgrading..." : "Start upgrade").frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(!m.canStart)

            ProgressView(value: min(max(m.progress, 0), 1))
                .progressViewStyle(.linear)

            Text(m.percentText)
                .font(.system(size: 12))
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .textSelection(.enabled)
        }
    }

    // MARK: - ④ 日志

    private var logCard: some View {
        cardBox {
            cardTitle("Log")
            ScrollViewReader { proxy in
                ScrollView {
                    Text(m.logText)
                        .font(.system(size: 11, design: .monospaced))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                        .id("logBottom")
                }
                .frame(height: 230)
                .onChange(of: m.logText) { _ in
                    proxy.scrollTo("logBottom", anchor: .bottom)
                }
            }
        }
    }

    // MARK: - 文件选择

    /// 选固件。走自己手动呈现的 DocumentPicker（见 DocumentPicker.swift），
    /// 不用 SwiftUI 的 .fileImporter —— 那个在同一个视图上挂两个就会失灵。
    private func pickFirmware() {
        DocumentPicker.shared.present(
            log: { m.log($0) },
            onPick: { url in m.loadFirmware(url: url) },
            onCancel: {})
    }

    private func pickRepairImage() {
        DocumentPicker.shared.present(
            log: { m.log($0) },
            onPick: { url in m.inspectAndRepair(url: url) },
            onCancel: {})
    }

}

/// 分享/导出面板（iOS 15 没有 ShareLink）
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

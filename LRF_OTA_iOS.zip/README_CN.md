# LRF OTA Updater —— iOS 版（功能对齐安卓 v1.8.2）

> 目标：产出一个 `.ipa`，用**全能签**签名后装到 iPhone 上，功能和安卓
> `LRF_OTA_Updater_v1.8.2（TANGOINNOS）.apk` 完全一致。

---

## 一、先说结论（很重要）

| 你要的 | 现状 |
|---|---|
| 源码工程（Swift / 可直接编译） | ✅ 已完成，就在这个文件夹 |
| 在本机（Windows）直接产出 `.ipa` | ❌ **不可能**，原因见下 |
| 产出 `.ipa` 的两条可行路径 | ✅ 见第二节，都不需要你买 Mac |

**为什么 Windows 出不了 `.ipa`**：`.ipa` 里装的是 `arm64-apple-ios` 的
Mach-O 二进制，只能用苹果的 iOS SDK 编译，而 iOS SDK 只随 Xcode 发布、
只能在 macOS 上运行。这不是工具选择问题，是苹果的封闭链路。虚拟机装
macOS 违反苹果许可、且在 Windows 上没有硬件加速（编译一次几小时），
实际不可行；本机 WSL 也被安全策略拦住，用不了。

**所以我把"最后一步"压到最短**：工程已经写到"只差敲一条编译命令"的程度，
下面两条路你二选一，都能拿到 `.ipa`。

---

## 二、拿到 `.ipa` 的两条路

### 路径 A：GitHub Actions 云编译（推荐，零成本，不需要 Mac）

GitHub 给公开仓库提供**免费的 macOS 机器**，我已经把编译脚本写好在
`.github/workflows/build-ipa.yml` 里了。

1. 注册/登录 GitHub（github.com）。
2. 右上角 **+ → New repository**，名字随便（比如 `lrf-ota-ios`），
   **Public**（私有仓库也能用免费额度，但公开最省事），创建。
3. 在新仓库页面点 **uploading an existing file**，把这个文件夹里的
   **全部内容**（不是压缩包本身）拖进去 —— 注意 `.github` 这个隐藏目录
   一定要带上，否则不会触发编译。
   *也可以直接拖这个文件夹的 zip（GitHub 会自动解压）。*
4. 上传完，点仓库顶部 **Actions** → 左侧 **build-ipa** → 右侧
   **Run workflow** → 绿色按钮 **Run workflow**。
5. 等 3～6 分钟，任务变绿后点进去，页面底部 **Artifacts** 里下载
   **LRFOTA-ipa**，解压得到 `LRFOTA_unsigned.ipa`。
6. 把这个 ipa 丢进全能签签名（见第三节）。

> **注意**：GitHub 网页版拖文件夹上传时，`.github` 这种以点开头的目录偶尔
> 会被浏览器忽略。上传完在仓库首页确认一下有没有 `.github/workflows/build-ipa.yml`；
> 如果没有，用仓库页 **Add file → Create new file**，文件名直接填
> `.github/workflows/build-ipa.yml`，把本文件夹里同名文件的内容粘进去提交即可。
>
> 编译失败怎么办：点开失败的那一步，把红色日志复制给我，我按报错改。
> 大概率是 Xcode 版本差异导致的个别 API 警告，改起来很快。

### 路径 B：借一台 Mac（最直接，10 分钟）

任何一台装了 Xcode 的 Mac（MacBook / iMac / 朋友的机器 / 网吧式云 Mac 都行）：

```bash
cd 这个文件夹
chmod +x build_ipa.sh
./build_ipa.sh
```

脚本会自己装 XcodeGen、生成工程、编译、打包，最后在当前目录得到
`LRFOTA.ipa`。**不需要开发者账号**，因为产物是未签名的，签名交给全能签。

---

## 三、全能签签名安装

1. 打开全能签，导入 `LRFOTA_unsigned.ipa`。
2. 选择你的证书（企业签 / 个人开发者证书都行），开始签名。
   *App 没有申请任何特殊权限（entitlements），只用蓝牙，所以普通证书
   都能签，不会出现"权限不匹配"。*
3. 签名完成后按提示安装（会走 `itms-services` 安装链接）。
4. 首次打开会弹 **"LRF OTA"想使用蓝牙** → 必须点**允许**，否则扫描列表
   永远是空的。
5. 如果提示"未受信任的开发者"，去 **设置 → 通用 → VPN与设备管理**
   信任对应证书。

**Bundle ID**：`com.tangoinons.lrfota`（如果证书不支持这个 ID，全能签
签名时可以改，改完不影响功能）。

---

## 四、功能对照（与安卓 v1.8.2 一一对应）

| 安卓 | iOS | 说明 |
|---|---|---|
| 扫描设备列表（按信号强度排序、可滚动） | ✅ | iOS 不给 MAC，显示 identifier 前 8 位 |
| 点设备连接 | ✅ | 连接参数一致：8 s 超时、最多试 5 次 |
| 选 `.hex` / `.bin` | ✅ | 走系统文件选择器（iCloud / 我的 iPhone 都行） |
| HEX 解析 / 整片 BIN 自动截 `0x1000~0x3C000` | ✅ | 逐行对应 `Firmware.kt` |
| CRC32 / 入口 / ImageFlag / IAP 体检 | ✅ | CRC32 算法与 `java.util.zip.CRC32` 完全一致 |
| 设备还在普通固件里也能升级（写 `0xFFE3`） | ✅ | 含"连续 3 次还在 APP 就补写一次"的逻辑 |
| 等设备重启进 OTA（校验 `0xFEE0` 服务） | ✅ | 不看名字就算成功，避免缓存误判 |
| 老 IAP 弹回 APP 的死锁报错 | ✅ | 同样的 bounce 计数与提示文案 |
| `0x84` 读分区上限 / 块大小 / CHIP_ID | ✅ | 一样的字节布局 |
| `0x81` 擦除 + 异步轮询 | ✅ | 一样的 `blocks*25ms+200ms` 起始等待 |
| `0x80` 编程 / `0x82` 校验 / `0x83` 结束 | ✅ | 一样的命令格式 |
| 每 32 包一次里程碑 VERIFY | ✅ | 同上 |
| "逐包校验"开关（慢 10 倍） | ✅ | 同上 |
| 进度条 + 百分比 + 实时日志 | ✅ | 日志可选中复制 |
| ★ 整片镜像修复（内置新 IAP、换掉老 IAP、导出） | ✅ | 内置 `iap_new.bin`，校验过入口 `6F 00 40 7B` |
| 修复后分享/导出 | ✅ | 存到「文件 > 我的 iPhone > LRF OTA」，或用分享面板发出去 |
| 升级中不锁屏 | ✅ | `isIdleTimerDisabled` |

### 三处"必然不同"的地方（不是没做，是 iOS 的限制）

1. **没有 MAC 地址**。iOS 不给 App 看外设 MAC，只能用系统分配的
   `identifier`。它同一台设备上是稳定的、重启也不变，所以"等设备重启
   回来"照样能找回同一个设备。
2. **拿不到 MTU**。用 `maximumWriteValueLength` 反推：iPhone 一般协商到
   185，每包 **176 字节**（安卓 247 → 240 字节），所以**同样的固件，
   iOS 会慢 20～30%**。协议完全一致，只是包小一点。
3. **无响应写没有回调**。流控改用 `canSendWriteWithoutResponse` +
   `peripheralIsReady`，这比安卓那套"指数退避重试"更准，不会出现
   "缓冲区满"的假超时。

---

## 五、上机自测清单

按顺序走一遍，哪一步不对就把日志发我：

1. 打开 App → 允许蓝牙 → 点 **Scan for devices** → 列表出现设备。
2. 选设备 → 状态显示 `Selected: xxx   ID xxxxxxxx`。
3. 点 **Choose file** → 选 `.hex` → 看 `CRC32=XXXXXXXX` 和安卓 App 显示
   的是否一致（**这一步最关键**，对不上说明文件选错了）。
4. 点 **Start upgrade** → 日志应依次出现：
   ```
   Firmware ... CRC32=... entry 6F xx xx xx
   Connecting to xxxxxxxx... (attempt 1)
   Connected to xxxxxxxx, max write 182 B (MTU ~185)
   0xFFE3 written, the device reboots now      ← 设备本来在普通固件里才有这行
   OTA connected, max write 182 B
   Device info: partition limit 0x3C000, block 4096 B, CHIP_ID 0x....
   Erasing 56 blocks from 0x1000...
   Erase complete
   Chunk 176 bytes (max write 182 B, write without response)
   Writing...
   Sent 5632 / 229476 B, waiting for the device...
   ...
   Writing the end marker...
   Upgrade complete: ...
   ```
5. 升级结束设备会自动关机（这颗板子复位即断电，正常现象），按键开机确认版本。

常见现象对照：

| 现象 | 原因 / 处理 |
|---|---|
| 扫描列表一直空 | 蓝牙权限没给：设置 → LRF OTA → 打开蓝牙 |
| `0xFFE3 written` 之后一直 `still waiting` | 设备是老 IAP：用 ★ 修复功能整片烧一次 |
| `The IAP bounced the device back...` | 同上，这是代码里专门识别的新 APP + 老 IAP 死锁 |
| 卡在 `Erasing...` | 设备供电不足或已掉电，重新上电再来 |
| `Write buffer stayed full` | 设备在擦 Flash，正常会自己恢复；反复出现说明信号太差 |

---

## 六、工程结构

```
LRF_OTA_iOS/
├── project.yml                  XcodeGen 工程定义（.xcodeproj 由它生成）
├── build_ipa.sh                 Mac 上一键出包
├── .github/workflows/build-ipa.yml   GitHub Actions 云编译（不需要 Mac）
├── LRFOTA/
│   ├── LRFOTAApp.swift          入口
│   ├── ContentView.swift        界面（五块卡片，对齐 activity_main.xml）
│   ├── AppModel.swift           状态与动作（对齐 MainActivity.kt）
│   ├── FotaEngine.swift         OTA 主流程（对齐 OtaManager.kt）
│   ├── Ble.swift                CoreBluetooth 封装（扫描 / 连接 / 读写）
│   ├── Firmware.swift           HEX / BIN 解析（对齐 Firmware.kt）
│   ├── IapRepair.swift          整片镜像修复（对齐 IapRepair.kt）
│   ├── Support.swift            错误类型 / 超时包装 / CRC32
│   ├── Info.plist               含蓝牙权限说明
│   ├── iap_new.bin              内置配套新 IAP（16 KB，入口 6F 00 40 7B）
│   └── Assets.xcassets/         图标
```

> 没有用 CocoaPods / SwiftPM 依赖，全部系统框架（CoreBluetooth + SwiftUI），
> 所以云编译不会因为拉不到依赖而失败。

---

## 七、版本

- 固件侧协议：`OnlyUpdateApp` IAP（`0xFEE0/0xFEE1`，命令 `0x80~0x84`）
- App 版本：1.8.2（对应安卓 v1.8.2）
- 最低 iOS：15.0（iPhone 6s 及以上）
- Bundle ID：`com.tangoinons.lrfota`
